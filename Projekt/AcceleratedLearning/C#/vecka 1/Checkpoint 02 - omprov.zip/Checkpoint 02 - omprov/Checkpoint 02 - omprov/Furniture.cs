﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Checkpoint_02___omprov
{
    class Furniture
    {
        public string Name { get; set; }
        public int Price { get; set; }
    }
}
