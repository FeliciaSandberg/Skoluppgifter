﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Checkpoint02___Rum
{
    class Rum
    {
        public string Storlek { get; set; }
        public string Room { get; set; }
    }
}
